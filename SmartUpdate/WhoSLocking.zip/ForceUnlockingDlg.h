#if !defined(AFX_FORCEUNLOCKINGDLG_H__7BB4EB97_AF04_11D3_BFEA_0010E3B966CE__INCLUDED_)
#define AFX_FORCEUNLOCKINGDLG_H__7BB4EB97_AF04_11D3_BFEA_0010E3B966CE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ForceUnlockingDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CForceUnlockingDlg dialog

class CForceUnlockingDlg : public CDialog
{
// Construction
public:
	BOOL m_bProcessRemoved;
	void SetParameters(LPCTSTR lpszProcessName, LPCTSTR lpszProcessID, LPCTSTR lpszExecutablePath, LPCTSTR lpszServiceName);
	CForceUnlockingDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CForceUnlockingDlg)
	enum { IDD = IDD_DIALOG_FORCE_UNLOCK };
	CString	m_szProcessID;
	CString	m_szServiceName;
	CString	m_szProcessName;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CForceUnlockingDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	BOOL m_bStopService;

	// Generated message map functions
	//{{AFX_MSG(CForceUnlockingDlg)
	virtual void OnOK();
	virtual BOOL OnInitDialog();
	afx_msg void OnTerminateProcess();
	afx_msg void OnStopService();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FORCEUNLOCKINGDLG_H__7BB4EB97_AF04_11D3_BFEA_0010E3B966CE__INCLUDED_)
