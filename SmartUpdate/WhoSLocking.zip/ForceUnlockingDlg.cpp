// ForceUnlockingDlg.cpp : implementation file
//

#include "stdafx.h"
#include "whoslocking.h"
#include "ForceUnlockingDlg.h"
#include "ServiceManager.h"
#include "WindowsErrorText.h"
#include "SimpleProcessAPI.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CForceUnlockingDlg dialog


CForceUnlockingDlg::CForceUnlockingDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CForceUnlockingDlg::IDD, pParent)
    , m_bProcessRemoved(FALSE)
    , m_bStopService(FALSE)
{
	//{{AFX_DATA_INIT(CForceUnlockingDlg)
	m_szProcessID = _T("");
	m_szServiceName = _T("");
	m_szProcessName = _T("");
	//}}AFX_DATA_INIT
}


void CForceUnlockingDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CForceUnlockingDlg)
	DDX_Text(pDX, IDC_PROCESS_ID, m_szProcessID);
	DDX_Text(pDX, IDC_SERVICE_NAME, m_szServiceName);
	DDX_Text(pDX, IDC_EDIT_PROCESS_NAME, m_szProcessName);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CForceUnlockingDlg, CDialog)
	//{{AFX_MSG_MAP(CForceUnlockingDlg)
	ON_BN_CLICKED(IDC_TERMINATE_PROCESS, OnTerminateProcess)
	ON_BN_CLICKED(IDC_STOP_SERVICE, OnStopService)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CForceUnlockingDlg message handlers

void CForceUnlockingDlg::OnOK() 
{
    if (m_bStopService) {
        // Stop service
        CServiceManager oServiceManager;
        if (oServiceManager.OpenServiceControlManager(NULL)) {
            if (oServiceManager.StopService(NULL,            // Local machine
                                            m_szServiceName, // Name of service
                                            TRUE             // also stop Dependent services
                                            )) {
                // OK
                m_bProcessRemoved = TRUE;
                CString szMessage = "Service ";
                szMessage+=m_szServiceName;
                szMessage+=" stopped successfully.";
                AfxMessageBox(szMessage, MB_OK|MB_ICONINFORMATION);
            } else {
                CString szMessage = "Couldn't stop service ";
                szMessage+=m_szServiceName;
                szMessage+=": ";
                TCHAR lpszBuf[4096];
                szMessage+=WindowsGetErrorText(GetLastError(), lpszBuf, sizeof(lpszBuf));
                AfxMessageBox(szMessage, MB_OK|MB_ICONERROR);
            }
        } else {
            CString szMessage = "Couldn't open Service Control Manager (SCM) on local machine: ";
            TCHAR lpszBuf[4096];
            szMessage+=WindowsGetErrorText(GetLastError(), lpszBuf, sizeof(lpszBuf));
            AfxMessageBox(szMessage, MB_OK|MB_ICONERROR);
        }
    } else {
        // Kill process (tough method)
        DWORD dwProcessID = atoi(m_szProcessID);
        if (CSimpleProcessAPI::TerminateProcess(dwProcessID)) {
            m_bProcessRemoved = TRUE;
            CString szMessage = "Process ";
            szMessage+=m_szProcessID;
            szMessage+=" terminated successfully.";
            AfxMessageBox(szMessage, MB_OK|MB_ICONINFORMATION);
        } else {
            CString szMessage = "Couldn't stop process ";
            szMessage+=m_szProcessID;
            szMessage+=": ";
            TCHAR lpszBuf[4096];
            szMessage+=WindowsGetErrorText(GetLastError(), lpszBuf, sizeof(lpszBuf));
            AfxMessageBox(szMessage, MB_OK|MB_ICONERROR);
        }
    }
	CDialog::OnOK();
}

void CForceUnlockingDlg::SetParameters(LPCTSTR lpszProcessName, LPCTSTR lpszProcessID, LPCTSTR lpszExecutablePath, LPCTSTR lpszServiceName)
{
    m_szProcessName = lpszProcessName;
    m_szProcessID = lpszProcessID;
    m_szServiceName = lpszServiceName;
}

BOOL CForceUnlockingDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
    if (m_szServiceName != "") {

        // It's a service: enable "Stop Service" button
        (GetDlgItem(IDC_STOP_SERVICE))->EnableWindow(TRUE);
        // set "Stop Service" as the default
        this->CheckRadioButton(IDC_STOP_SERVICE, IDC_TERMINATE_PROCESS, IDC_STOP_SERVICE);
        // Enable OK button
        OnStopService();

    } else {

        // It's a process: disable "Stop Service" button
        (GetDlgItem(IDC_STOP_SERVICE))->EnableWindow(FALSE);
        // set "Terminate Process" as the default
        this->CheckRadioButton(IDC_STOP_SERVICE, IDC_TERMINATE_PROCESS, IDC_TERMINATE_PROCESS);
        // Enable OK button
        OnTerminateProcess();

    }

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CForceUnlockingDlg::OnTerminateProcess() 
{
    // Enable the OK button
    (GetDlgItem(IDOK))->EnableWindow(TRUE);
    m_bStopService = FALSE;
}

void CForceUnlockingDlg::OnStopService() 
{
    // Enable the OK button
    (GetDlgItem(IDOK))->EnableWindow(TRUE);
    m_bStopService = TRUE;
}
