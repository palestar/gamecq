//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by WhoSLocking.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_WHOSLOCKING_DIALOG          102
#define IDR_MAINFRAME                   128
#define IDD_DIALOG_FORCE_UNLOCK         129
#define IDC_EDIT_MODULE_NAME            1000
#define IDC_BROWSE_DLL_NAME             1002
#define IDC_REFRESH                     1003
#define IDC_LIST_PROCESSES              1004
#define IDC_MESSAGE_TEXT                1005
#define IDC_FRAME_LIST_PROCESS          1006
#define IDC_FRAME_DLL_MODULE            1007
#define IDC_EDIT1                       1008
#define IDC_STOP_SERVICE                1009
#define IDC_TERMINATE_PROCESS           1010
#define IDC_SERVICE_NAME                1011
#define IDC_PROCESS_ID                  1012
#define IDC_EDIT_PROCESS_NAME           1013

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1014
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
