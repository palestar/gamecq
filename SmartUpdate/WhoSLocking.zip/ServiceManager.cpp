/*=========================================================================== 
    (c) Copyright 1999, Emmanuel KARTMANN, all rights reserved
  =========================================================================== 
    File           : ServiceManager.cpp
    $Header: $
    Author         : Emmanuel KARTMANN
    Creation       : Wednesday 12/1/99 4:59:02 PM
    Remake         : 
  ------------------------------- Description ------------------------------- 

           Implementation of the CServiceManager class.

  ------------------------------ Modifications ------------------------------ 
    $Log: $  
  =========================================================================== 
*/

#include "stdafx.h"
#include "ServiceManager.h"
#include <assert.h>

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CServiceManager::CServiceManager()
    : m_schSCManager(NULL)
    , m_schService(NULL)
{
    SetMachineName("");
    SetServiceName("");
}

CServiceManager::~CServiceManager()
{
    CloseService();
    CloseServiceControlManager();
}

//////////////////////////////////////////////////////////////////////
// Others
//////////////////////////////////////////////////////////////////////

void CServiceManager::SetMachineName(LPCTSTR lpszMachineName)
{
    if (lpszMachineName) {
        strcpy(m_lpszMachineName, lpszMachineName);
    } else {
        strcpy(m_lpszMachineName, "");
    }
}

void CServiceManager::SetServiceName(LPCTSTR lpszServiceName)
{
    if (lpszServiceName) {
        strcpy(m_lpszServiceName, lpszServiceName);
    } else {
        strcpy(m_lpszServiceName, "");
    }
}

BOOL CServiceManager::OpenServiceControlManager(LPCTSTR lpszMachineName)
{
    BOOL bRet = TRUE;

    if (lpszMachineName) {
        // If machine name has been passed, then we must close old SCM and open the new
        if (stricmp(lpszMachineName, m_lpszMachineName)) {
            // Not the same machine: need to close and open
            CloseServiceControlManager();
            SetMachineName(lpszMachineName);
            m_schSCManager = ::OpenSCManager(m_lpszMachineName, 0, SC_MANAGER_ALL_ACCESS);
        }
    } else {
        // NULL machine name: reuse old handle (if any)
        if (!m_schSCManager) {
            // No old handle: use local machine
            SetMachineName("local");
            m_schSCManager = ::OpenSCManager(NULL, 0, SC_MANAGER_ALL_ACCESS);
        }
    }

	if(!m_schSCManager) {
        bRet = FALSE;
		TCHAR szErr[256];
		Print(TEXT("OpenSCManager failed - %s\n"), GetErrorText(GetLastError(), szErr,256));
    }

    return(bRet);
}

BOOL CServiceManager::CloseServiceControlManager()
{
    BOOL bRet = TRUE;

    if (m_schSCManager) {
        bRet = ::CloseServiceHandle(m_schSCManager);
        m_schSCManager=NULL;
    }

    return(bRet);
}

BOOL CServiceManager::OpenService(LPCTSTR lpszServiceName)
{
    BOOL bRet = TRUE;

    if (lpszServiceName) {
        // If service name has been passed, then we must close old service and open the new
        if (stricmp(lpszServiceName, m_lpszServiceName)) {
            // Not the same machine: need to close and open
            CloseService();
            SetServiceName(lpszServiceName);
            // Check if name is an internal or display name
            TCHAR lpszServiceInternalName[256];
            DWORD dwBufferSize = sizeof(lpszServiceInternalName);
            if (::GetServiceKeyName(m_schSCManager, lpszServiceName, lpszServiceInternalName, &dwBufferSize)) {
                // It was a display name: switch to real (internal) name of service
                SetServiceName(lpszServiceInternalName);
            }
            m_schService = ::OpenService(m_schSCManager, m_lpszServiceName, SERVICE_ALL_ACCESS);
        }
    } else {
        // NULL service name: reuse old handle (if any)
        if (!m_schService) {
            // No previous handle, no machine name passed: error (INVALID_PARAM)
            SetLastError(ERROR_INVALID_PARAMETER);
        }
    }

	if(!m_schService) {
        bRet = FALSE;
		TCHAR szErr[256];
		Print(TEXT("OpenService failed - %s\n"), GetErrorText(GetLastError(), szErr,256));
    }

    return(bRet);
}

BOOL CServiceManager::CloseService()
{
    BOOL bRet = TRUE;

    if (m_schService) {
        bRet = ::CloseServiceHandle(m_schService);
        m_schService=NULL;
    }

    return(bRet);
}

BOOL CServiceManager::StartService(LPCTSTR lpszMachineName, LPCTSTR lpszServiceName, BOOL bStartDependents)
{
	BOOL bRet = FALSE;

    if (OpenServiceControlManager(lpszMachineName)) {

        if (OpenService(lpszServiceName)) {

			// try to start the service
			Print(TEXT("Starting up service %s on host %s ..."), m_lpszServiceName, m_lpszMachineName);

            bRet = StartService(m_schSCManager, m_schService);

            if (bRet) {

                    Print(TEXT("\n%s started on host %s.\n"), m_lpszServiceName, m_lpszMachineName);

            } else {

				// StartService failed
				TCHAR szErr[256];
				Print(TEXT("\n%s failed to start on host %s: %s\n"), m_lpszServiceName, m_lpszMachineName, GetErrorText(GetLastError(), szErr,256));

			}

		} else {
			TCHAR szErr[256];
			Print(TEXT("OpenService failed - %s\n"), GetErrorText(GetLastError(), szErr,256));
		}

    }

    // Start services that depend on this service
    if (bRet) {
        if (bStartDependents) {
            // Stop dependent services
            Print(TEXT("\nStarting dependent services ...\n"));
            bRet = QueryDependentServices(NULL, NULL, NTS_LIST_START);
        } else {
            Print(TEXT("\nUse /START option to start all dependent services.\n"));
        }
    }

	return bRet;
}

BOOL CServiceManager::StopService(LPCTSTR lpszMachineName, LPCTSTR lpszServiceName, BOOL bStopDependents)
{
	BOOL bRet = FALSE;

    if (OpenServiceControlManager(lpszMachineName)) {

        if (OpenService(lpszServiceName)) {

			// try to stop the service
		    Print(TEXT("Stopping service %s on host %s ..."), m_lpszServiceName, m_lpszMachineName);
            bRet = StopService(m_schSCManager, m_schService);

            if (bRet) {

                Print(TEXT("\n%s stopped on host %s.\n"), m_lpszServiceName, m_lpszMachineName);

            } else {

                Print(TEXT("\n%s failed to stop on host %s\n"), m_lpszServiceName, m_lpszMachineName);

                DWORD lastError = GetLastError();
			    TCHAR szErr[256];
                switch (lastError) {
                case ERROR_SERVICE_NOT_ACTIVE:
                    Print(TEXT("%s is not running on host %s ...\n"), m_lpszServiceName, m_lpszMachineName);
                    // We tried to stop a service that's not running: not an error
                    bRet = TRUE;
                    break;
                case ERROR_DEPENDENT_SERVICES_RUNNING:
			        Print(TEXT("StopService failed - %s\n"), GetErrorText(lastError, szErr,256));
                    if (bStopDependents) {
                        // Stop dependent services
                        Print(TEXT("\nStopping dependent services ...\n"));
                        bRet = QueryDependentServices(NULL, NULL, NTS_LIST_STOP);
                        if (bRet) {
                            // Now that all dependent services are stopped, retry on the service itself
                            bRet = StopService(m_schSCManager, m_schService);
                            if (bRet) {
                                Print(TEXT("\n%s stopped on host %s.\n"), m_lpszServiceName, m_lpszMachineName);
                            } else {
			                    Print(TEXT("StopService failed - %s\n"), GetErrorText(lastError, szErr,256));
                                break;
                            }
                        }
                    } else {
                        Print(TEXT("\nUse /STOP option to stop all dependent services.\n"));
                        QueryDependentServices(NULL, NULL, NTS_LIST_PRINT_NO_HEADER);
                    }
                    break;
                default:
			        Print(TEXT("StopService failed - %s\n"), GetErrorText(lastError, szErr,256));
                    break;
                }
            }

		}

    }

	return bRet;
}

BOOL CServiceManager::QueryDependentServices(LPCTSTR lpszMachineName, LPCTSTR lpszServiceName, NTSAction nServiceAction)
{
    BOOL bRet = FALSE;

    ENUM_SERVICE_STATUS lpServices[256];
    DWORD dwServicesSize = sizeof(lpServices);
    DWORD cbBytesNeeded = 0;
    DWORD dwServices = 0;

    if (OpenServiceControlManager(lpszMachineName)) {

        if (OpenService(lpszServiceName)) {

            bRet = EnumDependentServices(m_schService, SERVICE_STATE_ALL, lpServices, dwServicesSize, &cbBytesNeeded, &dwServices);

            if (bRet) {
                // Loop on all returned services
                if (dwServices>0) {

                    if (nServiceAction == NTS_LIST_PRINT) {
                        Print(TEXT("\nThis service has other services that depend on it:\n"));
                    }

                    SC_HANDLE schService = NULL;
                    LPQUERY_SERVICE_CONFIG lpServiceConfig = NULL;

                    for (DWORD i=0; i<dwServices; i++) {

                        switch (nServiceAction) {

                        case NTS_LIST_PRINT:
                        case NTS_LIST_PRINT_NO_HEADER:
                            {
                                schService = ::OpenService(m_schSCManager, lpServices[i].lpServiceName, SERVICE_ALL_ACCESS);
                                if (schService) {
                                    lpServiceConfig = QueryServiceConfiguration(m_schSCManager, schService);
                                }
                                ::CloseServiceHandle(schService);
                                schService=NULL;
                                PrintServiceInfo(i+1, &(lpServices[i].ServiceStatus), lpServices[i].lpServiceName, lpServices[i].lpDisplayName, lpServiceConfig);
                                if (lpServiceConfig) {
                                    LocalFree((void *)lpServiceConfig);
                                }
                            }
                            break;

                        case NTS_LIST_STOP:
                            // Non-recursive: open service and stop it

                            schService = ::OpenService(m_schSCManager, lpServices[i].lpServiceName, SERVICE_ALL_ACCESS);
                            if (schService) {
                                lpServiceConfig = QueryServiceConfiguration(m_schSCManager, m_schService);
                            }
                            PrintServiceInfo(i+1, &(lpServices[i].ServiceStatus), lpServices[i].lpServiceName, lpServices[i].lpDisplayName, lpServiceConfig);
                            if (lpServiceConfig) {
                                LocalFree((void *)lpServiceConfig);
                            }
                            if (schService) {

                                if (StopService(m_schSCManager, schService)) {
                                    Print(TEXT("         %s stopped on host %s.\n"), lpServices[i].lpServiceName, m_lpszMachineName);
                                } else {
                                    bRet = FALSE;
                                }
                                ::CloseServiceHandle(schService);
                                schService=NULL;

                            } else {
		                        TCHAR szErr[256];
		                        Print(TEXT("OpenService failed - %s\n"), GetErrorText(GetLastError(), szErr,256));
                            }
                            break;

                        case NTS_LIST_START:
                            // Non-recursive: open service and start it
                            schService = ::OpenService(m_schSCManager, lpServices[i].lpServiceName, SERVICE_ALL_ACCESS);

                            if (schService) {
                                lpServiceConfig = QueryServiceConfiguration(m_schSCManager, m_schService);
                            }
                            PrintServiceInfo(i+1, &(lpServices[i].ServiceStatus), lpServices[i].lpServiceName, lpServices[i].lpDisplayName, lpServiceConfig);
                            if (lpServiceConfig) {
                                LocalFree((void *)lpServiceConfig);
                            }

                            schService = ::OpenService(m_schSCManager, lpServices[i].lpServiceName, SERVICE_ALL_ACCESS);

                            if (schService) {

                                if (StartService(m_schSCManager, schService)) {
                                    Print(TEXT("         %s started on host %s.\n"), lpServices[i].lpServiceName, m_lpszMachineName);
                                } else {
                                    bRet = FALSE;
                                }
                                ::CloseServiceHandle(schService);
                                schService=NULL;

                            } else {
		                        TCHAR szErr[256];
		                        Print(TEXT("OpenService failed - %s\n"), GetErrorText(GetLastError(), szErr,256));
                            }
                            break;

                        }

                    }

                }
            } else {
		        TCHAR szErr[256];
		        Print(TEXT("EnumDependentServices failed - %s\n"), GetErrorText(GetLastError(), szErr,256));
            }
        }
    }

	return bRet;
}

BOOL CServiceManager::QueryService(LPCTSTR lpszMachineName, LPCTSTR lpszServiceName)
{
	BOOL bRet = FALSE;
    SERVICE_STATUS ssStatus;

    if (OpenServiceControlManager(lpszMachineName)) {

        if (OpenService(lpszServiceName)) {

			// Get service status
            if(::QueryServiceStatus(m_schService, &ssStatus)) {

                switch (ssStatus.dwCurrentState) {
                case SERVICE_STOPPED:
                    Print(TEXT("The %s service is not running on host %s.\n"), m_lpszServiceName, m_lpszMachineName);
                    break;
                case SERVICE_START_PENDING:
                    Print(TEXT("The %s service is starting on host %s.\n"), m_lpszServiceName, m_lpszMachineName);
                    break;
                case SERVICE_STOP_PENDING:
                    Print(TEXT("The %s service is stopping on host %s.\n"), m_lpszServiceName, m_lpszMachineName);
                    break;
                case SERVICE_RUNNING:
                    Print(TEXT("The %s service is running on host %s.\n"), m_lpszServiceName, m_lpszMachineName);
                    break;
                case SERVICE_CONTINUE_PENDING:
                    Print(TEXT("The %s service continue is pending on host %s.\n"), m_lpszServiceName, m_lpszMachineName);
                    break;
                case SERVICE_PAUSE_PENDING:
                    Print(TEXT("The %s service pause is pending on host %s.\n"), m_lpszServiceName, m_lpszMachineName); 
                    break;
                case SERVICE_PAUSED:
                    Print(TEXT("The %s service is paused on host %s.\n"), m_lpszServiceName, m_lpszMachineName); 
                    break;
                }

                bRet = TRUE;

            } else {
			    TCHAR szErr[256];
			    Print(TEXT("QueryServiceStatus failed - %s\n"), GetErrorText(GetLastError(), szErr,256));
		    }

            // Get Service Configuration
            QueryServiceConfiguration((LPCTSTR)NULL, (LPCTSTR)NULL);

            // Get dependent services (if any)
            QueryDependentServices(NULL, NULL, NTS_LIST_PRINT);

        } else {
			TCHAR szErr[256];
			Print(TEXT("OpenService failed - %s\n"), GetErrorText(GetLastError(), szErr,256));
		}

    } else {
		TCHAR szErr[256];
		Print(TEXT("OpenSCManager failed - %s\n"), GetErrorText(GetLastError(), szErr,256));
	}


	return bRet;
}

BOOL CServiceManager::ListServices(LPCTSTR lpszMachineName) 
{
	BOOL bRet = FALSE;
    ENUM_SERVICE_STATUS lpServices[20];
    DWORD dwServicesSize = sizeof(lpServices);
    DWORD cbBytesNeeded = 0;
    DWORD dwServices = 0;
    DWORD dwResumeHandle = 0;
    BOOL bHeaderPrinted = FALSE;
    BOOL bTheEnd = FALSE;
    int nCount=0;

    if (OpenServiceControlManager(lpszMachineName)) {

        DWORD dwLastError = ERROR_MORE_DATA;
        SC_HANDLE schService = NULL;
        LPQUERY_SERVICE_CONFIG lpServiceConfig = NULL;

        while (dwLastError == ERROR_MORE_DATA) {
            // Print services
            if (dwServices>0) {
                if (!bHeaderPrinted) {
                    Print(TEXT("\nServices installed on computer %s:\n"), m_lpszMachineName);
                    bHeaderPrinted=TRUE;
                }
                for (DWORD i=0; i<dwServices; i++) {
                    nCount++;
                    schService = ::OpenService(m_schSCManager, lpServices[i].lpServiceName, SERVICE_ALL_ACCESS);
                    if (schService) {
                        lpServiceConfig = QueryServiceConfiguration(m_schSCManager, schService);
                    }
                    ::CloseServiceHandle(schService);
                    schService=NULL;
                    PrintServiceInfo(nCount, &(lpServices[i].ServiceStatus), lpServices[i].lpServiceName, lpServices[i].lpDisplayName, lpServiceConfig);
                    if (lpServiceConfig) {
                        LocalFree((void *)lpServiceConfig);
                    }
                }
            }

            if (bTheEnd) {
                break;
            }

            dwResumeHandle += dwServices /* *sizeof(ENUM_SERVICE_STATUS)*/;
            dwServices = 0;
            cbBytesNeeded = 0;
            bRet = EnumServicesStatus(m_schSCManager,      // handle to service control manager database
                                      SERVICE_WIN32,     // type of services to enumerate (we're not interested in SERVICE_DRIVERs)
                                      SERVICE_STATE_ALL, // state of services to enumerate
                                      lpServices,        // pointer to service status buffer
                                      dwServicesSize,    // size of service status buffer
                                      &cbBytesNeeded,    // pointer to variable for bytes needed
                                      &dwServices,       // pointer to variable for number returned
                                      &dwResumeHandle    // pointer to variable for next entry
                                      );
            if (!bRet) {
                dwLastError = GetLastError();
            }
            if (dwResumeHandle ==0) {
                bTheEnd = TRUE;
            }

        }

        if (dwLastError != ERROR_MORE_DATA) {
		    TCHAR szErr[256];
		    Print(TEXT("EnumServicesStatus failed - %s\n"), GetErrorText(GetLastError(), szErr,256));
	    }

    } else {
		TCHAR szErr[256];
		Print(TEXT("OpenSCManager failed - %s\n"), GetErrorText(GetLastError(), szErr,256));
	}


	return bRet;
}

LPTSTR CServiceManager::GetErrorText(DWORD errorCode, LPTSTR lpszBuf, DWORD dwSize)
{
    LPTSTR lpszTemp = 0;

    DWORD dwRet =	::FormatMessage(
						FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM |FORMAT_MESSAGE_ARGUMENT_ARRAY,
						0,
						errorCode,
						LANG_NEUTRAL,
						(LPTSTR)&lpszTemp,
						0,
						0
					);

    if( !dwRet || (dwSize < dwRet+14) )
        lpszBuf[0] = TEXT('\0');
    else {
        lpszTemp[_tcsclen(lpszTemp)-2] = TEXT('\0');  //remove cr/nl characters
        _tcscpy(lpszBuf, lpszTemp);
    }

    if( lpszTemp )
        LocalFree(HLOCAL(lpszTemp));

    return lpszBuf;
}


BOOL CServiceManager::Open(LPCTSTR lpszMachineName, LPCTSTR lpszServiceName)
{
    BOOL bRet = TRUE;

    bRet &= OpenServiceControlManager(lpszMachineName);
    bRet &= OpenService(lpszServiceName);

    return(bRet);
}

BOOL CServiceManager::Print(LPCTSTR lpszFormat, LPCTSTR lpszParam1, LPCTSTR lpszParam2, LPCTSTR lpszParam3, LPCTSTR lpszParam4, LPCTSTR lpszParam5)
{
    // Default implementation: print in console
    int nPrintResult = 0;
    if (lpszParam1 == NULL) {
    	nPrintResult = _tprintf(lpszFormat);
    } else if (lpszParam2 == NULL) {
	    nPrintResult = _tprintf(lpszFormat, lpszParam1);
    } else if (lpszParam3 == NULL) {
	    nPrintResult = _tprintf(lpszFormat, lpszParam1, lpszParam2);
    } else if (lpszParam4 == NULL) {
	    nPrintResult = _tprintf(lpszFormat, lpszParam1, lpszParam2, lpszParam3);
    } else if (lpszParam5 == NULL) {
	    nPrintResult = _tprintf(lpszFormat, lpszParam1, lpszParam2, lpszParam3, lpszParam4);
    } else {
	    nPrintResult = _tprintf(lpszFormat, lpszParam1, lpszParam2, lpszParam3, lpszParam4, lpszParam5);
    }

    if (nPrintResult < 0) {
        return(FALSE);
    }

    return(TRUE);
}

LPSTR CServiceManager::GetStatusString(DWORD dwServiceStatus)
{
    LPSTR lpszServiceStatus = NULL;
    switch (dwServiceStatus) {
    case SERVICE_STOPPED:
        lpszServiceStatus = new char[strlen("Stopped")+1];
        strcpy(lpszServiceStatus, "Stopped");
        break;
    case SERVICE_START_PENDING:
        lpszServiceStatus = new char[strlen("Start Pending")+1];
        strcpy(lpszServiceStatus, "Start Pending");
        break;
    case SERVICE_STOP_PENDING:
        lpszServiceStatus = new char[strlen("Stop Pending")+1];
        strcpy(lpszServiceStatus, "Stop Pending");
        break;
    case SERVICE_RUNNING:
        lpszServiceStatus = new char[strlen("Started")+1];
        strcpy(lpszServiceStatus, "Started");
        break;
    case SERVICE_CONTINUE_PENDING:
        lpszServiceStatus = new char[strlen("Continue Pending")+1];
        strcpy(lpszServiceStatus, "Continue Pending");
        break;
    case SERVICE_PAUSE_PENDING:
        lpszServiceStatus = new char[strlen("Pause Pending")+1];
        strcpy(lpszServiceStatus, "Pause Pending");
        break;
    case SERVICE_PAUSED:
        lpszServiceStatus = new char[strlen("Paused")+1];
        strcpy(lpszServiceStatus, "Paused");
        break;
    }
    return(lpszServiceStatus);
}

LPSTR CServiceManager::GetStartupString(DWORD dwServiceStartupType)
{
    LPSTR lpszServiceStartupType = NULL;
    switch (dwServiceStartupType) {
    case SERVICE_BOOT_START:
        lpszServiceStartupType = new char[strlen("Boot")+1];
        strcpy(lpszServiceStartupType, "Boot");
        break;
    case SERVICE_SYSTEM_START:
        lpszServiceStartupType = new char[strlen("System")+1];
        strcpy(lpszServiceStartupType, "System");
        break;
    case SERVICE_AUTO_START:
        lpszServiceStartupType = new char[strlen("Automatic")+1];
        strcpy(lpszServiceStartupType, "Automatic");
        break;
    case SERVICE_DEMAND_START:
        lpszServiceStartupType = new char[strlen("Manual")+1];
        strcpy(lpszServiceStartupType, "Manual");
        break;
    case SERVICE_DISABLED:
        lpszServiceStartupType = new char[strlen("Disabled")+1];
        strcpy(lpszServiceStartupType, "Disabled");
        break;
    }
    return(lpszServiceStartupType);
}

BOOL CServiceManager::PrintServiceInfo(int nCount, SERVICE_STATUS *ServiceStatus, LPCTSTR lpszServiceName, LPCTSTR lpszDisplayName, LPQUERY_SERVICE_CONFIG lpServiceConfig)
{
    BOOL bRet = FALSE;
    LPSTR lpszServiceStartup = NULL;
    LPSTR lpszServiceStatus = NULL;

    // Get a string for the state
    lpszServiceStatus = GetStatusString(ServiceStatus->dwCurrentState);

    // Get a string for the startup type
    if (lpServiceConfig) {
        lpszServiceStartup = GetStartupString(lpServiceConfig->dwStartType);
    } else {
        lpszServiceStartup = new char[2];
        strcpy(lpszServiceStartup, "?");
    }

    // Convert service number into a string
    TCHAR szCount[16];
    sprintf(szCount, "%d", nCount);

    // Call virtual function "Print"
    bRet = Print(TEXT("    %3s. (%s/%s) %s (\"%s\")\n"), szCount, lpszServiceStatus, lpszServiceStartup, lpszServiceName, lpszDisplayName);

    // Cleanup
    if (lpszServiceStatus) {
        delete [] lpszServiceStatus;
    }
    if (lpszServiceStartup) {
        delete [] lpszServiceStartup;
    }

    return(bRet);
}

BOOL CServiceManager::StopService(SC_HANDLE m_schSCManager, SC_HANDLE m_schService)
{
    BOOL bRet = FALSE;
    SERVICE_STATUS ssStatus;

	if( ::ControlService(m_schService, SERVICE_CONTROL_STOP, &ssStatus) ) {
		::Sleep(1000);

		while( ::QueryServiceStatus(m_schService, &ssStatus) ) {
			if( ssStatus.dwCurrentState == SERVICE_STOP_PENDING ) {
				Print(TEXT("."));
				::Sleep( 1000 );
            } else {
				break;
            }
		}

        if( ssStatus.dwCurrentState == SERVICE_STOPPED ) {
			bRet = TRUE;
        }
    }

    return(bRet);
}

BOOL CServiceManager::StartService(SC_HANDLE schSCManager, SC_HANDLE schService)
{
    BOOL bRet = FALSE;
    SERVICE_STATUS ssStatus;

    assert(schService);

	if( ::StartService(schService, 0, 0) ) {
		Sleep(1000);

		while( ::QueryServiceStatus(schService, &ssStatus) ) {
			if( ssStatus.dwCurrentState == SERVICE_START_PENDING ) {
				Print(TEXT("."));
				Sleep( 1000 );
            } else {
				break;
            }
		}

        if( ssStatus.dwCurrentState == SERVICE_RUNNING ) {
			bRet = TRUE;
        }
    }

    return(bRet);
}

BOOL CServiceManager::QueryServiceConfiguration(LPCTSTR lpszMachineName, LPCTSTR lpszServiceName)
{
	BOOL bRet = FALSE;
    LPQUERY_SERVICE_CONFIG lpqscBuf = NULL; 
    DWORD dwBytesNeeded=0; 

    if (OpenServiceControlManager(lpszMachineName)) {

        if (OpenService(lpszServiceName)) {

            lpqscBuf = QueryServiceConfiguration(m_schSCManager, m_schService);

            if (lpqscBuf != NULL) {

                switch (lpqscBuf->dwStartType) {
                case SERVICE_BOOT_START:
                    Print(TEXT("The %s service is configured as a device driver started by the system loader on host %s.\n"), m_lpszServiceName, m_lpszMachineName);
                    break;
                case SERVICE_SYSTEM_START:
                    Print(TEXT("The %s service is configured as a device driver started by the IoInitSystem function on host %s.\n"), m_lpszServiceName, m_lpszMachineName);
                    break;
                case SERVICE_AUTO_START:
                    Print(TEXT("The %s service is configured to start at boot on host %s.\n"), m_lpszServiceName, m_lpszMachineName);
                    break;
                case SERVICE_DEMAND_START:
                    Print(TEXT("The %s service is configured to start on demand on host %s.\n"), m_lpszServiceName, m_lpszMachineName);
                    break;
                case SERVICE_DISABLED:
                    Print(TEXT("The %s service is disabled on host %s.\n"), m_lpszServiceName, m_lpszMachineName);
                    break;
                default:
                    TCHAR lpszStartType[16];
                    sprintf(lpszStartType, "%d", lpqscBuf->dwStartType);
                    Print(TEXT("The %s service start type is unknown (%s) on host %s.\n"), m_lpszServiceName, lpszStartType, m_lpszMachineName);
                    break;
                }

                bRet = TRUE;

            }

        } else {
			TCHAR szErr[256];
			Print(TEXT("OpenService failed - %s\n"), GetErrorText(GetLastError(), szErr,256));
		}

    } else {
		TCHAR szErr[256];
		Print(TEXT("OpenSCManager failed - %s\n"), GetErrorText(GetLastError(), szErr,256));
	}

    // Cleanup
    if (lpqscBuf) {
        LocalFree((void *)lpqscBuf);
        lpqscBuf=NULL;
    }
	return bRet;
}

LPQUERY_SERVICE_CONFIG CServiceManager::QueryServiceConfiguration(SC_HANDLE schSCManager, SC_HANDLE schService)
{
    LPQUERY_SERVICE_CONFIG lpqscBuf = NULL; 
    DWORD dwBytesNeeded=0; 

    assert(schService);

    lpqscBuf = (LPQUERY_SERVICE_CONFIG) LocalAlloc(LPTR, 8192);

    if (lpqscBuf != NULL) {

        if (!::QueryServiceConfig(schService, lpqscBuf, 8192, &dwBytesNeeded)) {

            LocalFree((void *)lpqscBuf);
            lpqscBuf=NULL;

			TCHAR szErr[256];
			Print(TEXT("QueryServiceConfig failed - %s\n"), GetErrorText(GetLastError(), szErr,256));
		}

    } else {
		TCHAR szErr[256];
		Print(TEXT("LocalAlloc failed - %s\n"), GetErrorText(GetLastError(), szErr,256));
    }

    return(lpqscBuf);
}
